<?php
session_start();
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'phplogin';

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exit('MySQL bağlantı hatası: ' . mysqli_connect_error());
}

// Kullanıcının etkinlik ID ve bilet sayısını gönderdiğini kontrol et
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $etkinlik_id = $_POST['etkinlik_id'];
    $bilet_sayisi = $_POST['bilet_sayisi'];

    // Etkinlik bilgilerini çekelim
    $stmt = $con->prepare("SELECT biletFiyati, kontenjan FROM etkinlikler WHERE id = ?");
    $stmt->bind_param("i", $etkinlik_id);
    $stmt->execute();
    $stmt->bind_result($biletFiyati, $kontenjan);
    $stmt->fetch();
    $stmt->close();

    // Toplam tutarı hesapla
    $toplam_tutar = $biletFiyati * $bilet_sayisi;

    // Kontenjan kontrolü yapalım
    if ($bilet_sayisi > $kontenjan) {
        echo "<script>alert('Seçtiğiniz etkinlik için yeterli kontenjan yok!'); window.location.href='uyeProfil.php';</script>";
        exit;
    }

    // Kontenjanı güncelle
    $yeni_kontenjan = $kontenjan - $bilet_sayisi;
    $update_stmt = $con->prepare("UPDATE etkinlikler SET kontenjan = ? WHERE id = ?");
    $update_stmt->bind_param("ii", $yeni_kontenjan, $etkinlik_id);
    if ($update_stmt->execute()) {
        echo "<script>alert('Bilet satın alındı! Güncellenmiş kontenjan: $yeni_kontenjan'); window.location.href='uyeProfil.php';</script>";
    } else {
        echo "<script>alert('Bilet satın alma işlemi sırasında hata oluştu!');</script>";
    }
    $update_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,minimum-scale=1">
    <title>Ödeme Sayfası</title>
    <link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="container">
        <h2>Ödeme Yap</h2>

        <p><b>Toplam Tutar:</b> <?= htmlspecialchars($toplam_tutar, ENT_QUOTES, 'UTF-8') ?> TL</p>

        <form action="odemeTamamla.php" method="post">
            <input type="hidden" name="etkinlik_id" value="<?= htmlspecialchars($etkinlik_id, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="bilet_sayisi" value="<?= htmlspecialchars($bilet_sayisi, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="toplam_tutar" value="<?= htmlspecialchars($toplam_tutar, ENT_QUOTES, 'UTF-8') ?>">

            <label for="kart_numarasi">Kart Numarası:</label>
            <input type="text" id="kart_numarasi" name="kart_numarasi" required maxlength="16">

            <label for="son_kullanma">Son Kullanma Tarihi:</label>
            <input type="text" id="son_kullanma" name="son_kullanma" placeholder="AA/YY" required>

            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" name="cvv" required maxlength="3">

            <button type="submit">Ödemeyi Tamamla</button>
        </form>
    </div>
</body>
</html>
